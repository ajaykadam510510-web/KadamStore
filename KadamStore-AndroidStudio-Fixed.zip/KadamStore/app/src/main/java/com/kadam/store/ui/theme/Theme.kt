package com.kadam.store.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val KadamGreen = Color(0xFF0F8F4D)
val KadamLeaf = Color(0xFFE9F8EF)
val KadamCream = Color(0xFFFFF7DF)
val KadamText = Color(0xFF102116)
val KadamMuted = Color(0xFF66756B)
val KadamBorder = Color(0xFFDDEADE)

private val LightScheme = lightColorScheme(
    primary = KadamGreen,
    onPrimary = Color.White,
    secondary = KadamLeaf,
    onSecondary = KadamText,
    background = Color(0xFFF8FFF8),
    onBackground = KadamText,
    surface = Color.White,
    onSurface = KadamText,
    surfaceVariant = KadamLeaf,
    onSurfaceVariant = KadamMuted,
    outline = KadamBorder,
    error = Color(0xFFD64545)
)

@Composable
fun KadamStoreTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = LightScheme,
        typography = MaterialTheme.typography,
        content = content
    )
}
