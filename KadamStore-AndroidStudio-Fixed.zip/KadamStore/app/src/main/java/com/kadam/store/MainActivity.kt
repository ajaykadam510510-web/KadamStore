package com.kadam.store

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import com.kadam.store.data.repository.AuthRepository
import com.kadam.store.data.repository.StoreRepository
import com.kadam.store.ui.screens.AuthScreen
import com.kadam.store.ui.screens.MainStoreScreen
import com.kadam.store.ui.theme.KadamStoreTheme
import com.kadam.store.viewmodel.AuthViewModel
import com.kadam.store.viewmodel.StoreViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val authRepository = remember { AuthRepository() }
            val storeRepository = remember { StoreRepository() }
            val authViewModel = remember { AuthViewModel(authRepository) }
            val storeViewModel = remember { StoreViewModel(storeRepository) }
            val authState by authViewModel.uiState.collectAsState()
            KadamStoreTheme {
                if (authState.user == null) {
                    AuthScreen(
                        state = authState,
                        onNameChange = authViewModel::onNameChange,
                        onEmailChange = authViewModel::onEmailChange,
                        onPasswordChange = authViewModel::onPasswordChange,
                        onModeChange = authViewModel::onModeChange,
                        onLogin = authViewModel::login,
                        onSignup = authViewModel::signup,
                        onForgotPassword = authViewModel::forgotPassword,
                        onDemoLogin = authViewModel::demoLogin
                    )
                } else {
                    MainStoreScreen(
                        user = authState.user,
                        viewModel = storeViewModel,
                        onLogout = authViewModel::logout
                    )
                }
            }
        }
    }
}
