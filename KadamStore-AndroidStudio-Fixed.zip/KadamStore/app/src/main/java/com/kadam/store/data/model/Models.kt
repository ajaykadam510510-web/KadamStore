package com.kadam.store.data.model

data class User(
    val id: String,
    val name: String,
    val email: String
)

data class StoredUser(
    val id: String,
    val name: String,
    val email: String,
    val password: String
)

data class Category(
    val id: String,
    val name: String,
    val icon: String,
    val color: Long
)

data class Product(
    val id: String,
    val name: String,
    val categoryId: String,
    val price: Int,
    val mrp: Int,
    val unit: String,
    val deliveryMinutes: Int,
    val rating: Double,
    val inStock: Boolean = true,
    val badge: String? = null
)

data class CartItem(
    val productId: String,
    val quantity: Int
)

data class CartLine(
    val product: Product,
    val quantity: Int,
    val lineTotal: Int
)

data class Address(
    val id: String,
    val label: String,
    val line: String,
    val latitude: Double? = null,
    val longitude: Double? = null
)

enum class PaymentMethod(val label: String) {
    Upi("UPI"),
    Card("Card"),
    CashOnDelivery("Cash on Delivery")
}

enum class OrderStatus(val label: String) {
    Placed("Placed"),
    Packed("Packed"),
    OutForDelivery("Out for delivery"),
    Delivered("Delivered")
}

data class Order(
    val id: String,
    val items: List<CartLine>,
    val address: Address,
    val paymentMethod: PaymentMethod,
    val status: OrderStatus,
    val subtotal: Int,
    val deliveryFee: Int,
    val discount: Int,
    val total: Int,
    val placedAt: Long,
    val etaMinutes: Int
)

enum class AuthMode {
    Signup,
    Login,
    Forgot
}

enum class StoreTab(val title: String) {
    Home("Home"),
    Search("Search"),
    Cart("Cart"),
    Orders("Orders"),
    Profile("Profile")
}
