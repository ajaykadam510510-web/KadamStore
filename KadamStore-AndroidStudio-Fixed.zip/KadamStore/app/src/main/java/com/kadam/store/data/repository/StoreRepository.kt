package com.kadam.store.data.repository

import com.kadam.store.data.model.Address
import com.kadam.store.data.model.CartItem
import com.kadam.store.data.model.CartLine
import com.kadam.store.data.model.Category
import com.kadam.store.data.model.Order
import com.kadam.store.data.model.OrderStatus
import com.kadam.store.data.model.PaymentMethod
import com.kadam.store.data.model.Product
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class StoreRepository {
    val categories = listOf(
        Category("fruits", "Fruits", "Fruit", 0xFFFFE4D6),
        Category("vegetables", "Vegetables", "Veg", 0xFFDDF8E8),
        Category("dairy", "Dairy", "Milk", 0xFFE4F0FF),
        Category("snacks", "Snacks", "Snack", 0xFFFFF1C9),
        Category("beverages", "Beverages", "Drink", 0xFFEADFFF),
        Category("household", "Household", "Home", 0xFFF3E8D7)
    )

    val products = listOf(
        Product("p1", "Alphonso Mango", "fruits", 189, 240, "1 kg", 9, 4.8, badge = "Fresh"),
        Product("p2", "Banana Robusta", "fruits", 48, 60, "6 pcs", 8, 4.7),
        Product("p3", "Kashmir Apple", "fruits", 156, 190, "1 kg", 10, 4.6),
        Product("p4", "Tomato Local", "vegetables", 32, 45, "500 g", 7, 4.5),
        Product("p5", "Coriander Bunch", "vegetables", 18, 25, "1 bunch", 7, 4.4, badge = "Daily"),
        Product("p6", "Amul Taaza Milk", "dairy", 58, 62, "1 L", 6, 4.9),
        Product("p7", "Paneer Fresh", "dairy", 96, 125, "200 g", 9, 4.6),
        Product("p8", "Masala Chips", "snacks", 20, 25, "52 g", 8, 4.3),
        Product("p9", "Roasted Makhana", "snacks", 139, 175, "100 g", 12, 4.7, badge = "Healthy"),
        Product("p10", "Cold Coffee", "beverages", 79, 99, "250 ml", 9, 4.5),
        Product("p11", "Tender Coconut Water", "beverages", 54, 65, "200 ml", 11, 4.4),
        Product("p12", "Dishwash Gel", "household", 112, 145, "500 ml", 14, 4.5)
    )

    val offers = listOf(
        "Morning essentials|Milk, bread and fruits in under 10 minutes",
        "Flat 20% off|Fresh vegetables for today’s cooking",
        "Weekend snack run|Chips, beverages and sweets delivered fast"
    )

    private val defaultAddress = Address(
        id = "home-default",
        label = "Home",
        line = "Kadam Store demo address, near your current location"
    )

    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _addresses = MutableStateFlow(listOf(defaultAddress))
    val addresses: StateFlow<List<Address>> = _addresses.asStateFlow()

    fun cartLines(): List<CartLine> {
        return _cart.value.mapNotNull { item ->
            val product = products.firstOrNull { it.id == item.productId } ?: return@mapNotNull null
            CartLine(product, item.quantity, product.price * item.quantity)
        }
    }

    fun addToCart(productId: String) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.productId == productId }
        if (index >= 0) {
            val item = current[index]
            current[index] = item.copy(quantity = item.quantity + 1)
        } else {
            current.add(CartItem(productId, 1))
        }
        _cart.value = current
    }

    fun decrement(productId: String) {
        _cart.value = _cart.value.mapNotNull { item ->
            if (item.productId == productId) {
                val nextQuantity = item.quantity - 1
                if (nextQuantity > 0) item.copy(quantity = nextQuantity) else null
            } else item
        }
    }

    fun removeFromCart(productId: String) {
        _cart.value = _cart.value.filterNot { it.productId == productId }
    }

    fun clearCart() {
        _cart.value = emptyList()
    }

    fun saveAddress(address: Address) {
        val current = _addresses.value.toMutableList()
        val index = current.indexOfFirst { it.id == address.id }
        if (index >= 0) current[index] = address else current.add(0, address)
        _addresses.value = current
    }

    fun placeOrder(address: Address, paymentMethod: PaymentMethod): Order? {
        val lines = cartLines()
        if (lines.isEmpty()) return null
        val subtotal = lines.sumOf { it.lineTotal }
        val deliveryFee = if (subtotal in 1..298) 25 else 0
        val discount = if (subtotal >= 499) 50 else 0
        val order = Order(
            id = "KS${(100000..999999).random()}",
            items = lines,
            address = address,
            paymentMethod = paymentMethod,
            status = OrderStatus.Placed,
            subtotal = subtotal,
            deliveryFee = deliveryFee,
            discount = discount,
            total = subtotal + deliveryFee - discount,
            placedAt = System.currentTimeMillis(),
            etaMinutes = 12
        )
        _orders.value = listOf(order) + _orders.value
        saveAddress(address)
        clearCart()
        return order
    }
}
