package com.kadam.store.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.kadam.store.data.model.Address
import com.kadam.store.data.model.PaymentMethod
import com.kadam.store.data.model.StoreTab
import com.kadam.store.data.model.User
import com.kadam.store.ui.components.CartLineRow
import com.kadam.store.ui.components.CategoryChip
import com.kadam.store.ui.components.KadamPrimaryButton
import com.kadam.store.ui.components.ProductCard
import com.kadam.store.ui.components.SummaryCard
import com.kadam.store.ui.components.rupee
import com.kadam.store.viewmodel.StoreUiState
import com.kadam.store.viewmodel.StoreViewModel

@Composable
fun MainStoreScreen(user: User, viewModel: StoreViewModel, onLogout: () -> Unit) {
    val state by viewModel.uiState.collectAsState()
    Scaffold(
        bottomBar = {
            NavigationBar {
                StoreTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = state.selectedTab == tab,
                        onClick = { viewModel.selectTab(tab) },
                        label = { Text(if (tab == StoreTab.Cart && state.cartCount > 0) "Cart ${state.cartCount}" else tab.title) },
                        icon = { Text(tab.title.take(1)) }
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(padding).padding(18.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (state.selectedTab) {
                StoreTab.Home -> HomeContent(state, viewModel)
                StoreTab.Search -> SearchContent(state, viewModel)
                StoreTab.Cart -> CartContent(state, viewModel)
                StoreTab.Orders -> OrdersContent(state)
                StoreTab.Profile -> ProfileContent(user, state, onLogout)
            }
        }
    }
}

@Composable
private fun HomeContent(state: StoreUiState, viewModel: StoreViewModel) {
    Header("Kadam Store", "Delivering in 8-12 minutes")
    Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(MaterialTheme.colorScheme.primary).padding(20.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Instant grocery delivery", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Fresh essentials at your door before breakfast gets cold.", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Free delivery above ${rupee(299)}. Save ${rupee(50)} above ${rupee(499)}.", color = Color.White)
        }
    }
    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        state.offers.forEach { offer ->
            val parts = offer.split("|")
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondary)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(parts.first(), fontWeight = FontWeight.Bold)
                    Text(parts.getOrElse(1) { "Fresh offer" })
                }
            }
        }
    }
    SectionTitle("Shop by category")
    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        state.categories.forEach { category ->
            CategoryChip(category, false) { viewModel.selectCategory(category.id) }
        }
    }
    SectionTitle("Featured today")
    state.products.take(6).forEach { product ->
        ProductCard(
            product = product,
            quantity = state.cartLines.firstOrNull { it.product.id == product.id }?.quantity ?: 0,
            onAdd = { viewModel.addToCart(product.id) },
            onRemove = { viewModel.decrement(product.id) }
        )
    }
}

@Composable
private fun SearchContent(state: StoreUiState, viewModel: StoreViewModel) {
    Header("Search groceries", "Live suggestions")
    OutlinedTextField(
        value = state.search,
        onValueChange = viewModel::setSearch,
        modifier = Modifier.fillMaxWidth(),
        label = { Text("Search fruits, milk, snacks") },
        shape = RoundedCornerShape(18.dp),
        singleLine = true
    )
    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        CategoryChip(com.kadam.store.data.model.Category("all", "All", "All", 0xFFE9F8EF), state.selectedCategoryId == null) { viewModel.selectCategory(null) }
        state.categories.forEach { category -> CategoryChip(category, state.selectedCategoryId == category.id) { viewModel.selectCategory(category.id) } }
    }
    Text("${state.filteredProducts.size} products found", color = MaterialTheme.colorScheme.onSurfaceVariant)
    state.filteredProducts.forEach { product ->
        ProductCard(
            product = product,
            quantity = state.cartLines.firstOrNull { it.product.id == product.id }?.quantity ?: 0,
            onAdd = { viewModel.addToCart(product.id) },
            onRemove = { viewModel.decrement(product.id) }
        )
    }
}

@Composable
private fun CartContent(state: StoreUiState, viewModel: StoreViewModel) {
    Header("Your cart", "Checkout")
    if (state.cartLines.isEmpty()) {
        EmptyText("Your cart is empty", "Add fresh groceries from Home or Search and checkout in seconds.")
    } else {
        state.cartLines.forEach { line ->
            CartLineRow(line, { viewModel.addToCart(line.product.id) }, { viewModel.decrement(line.product.id) }, { viewModel.removeFromCart(line.product.id) })
        }
        SummaryCard(state.subtotal, state.deliveryFee, state.discount, state.total, "Choose address and pay") {
            viewModel.selectTab(StoreTab.Cart)
        }
        CheckoutBlock(state, viewModel)
    }
}

@Composable
private fun CheckoutBlock(state: StoreUiState, viewModel: StoreViewModel) {
    SectionTitle("Delivery address")
    state.addresses.forEach { address -> AddressCard(address) { viewModel.placeOrder(address) } }
    KadamPrimaryButton("Use current location") { viewModel.useCurrentLocationAddress() }
    OutlinedTextField(
        value = state.manualAddress,
        onValueChange = viewModel::setManualAddress,
        modifier = Modifier.fillMaxWidth(),
        label = { Text("Or type apartment, street and landmark") },
        shape = RoundedCornerShape(18.dp),
        minLines = 2
    )
    SectionTitle("Payment")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        PaymentMethod.entries.forEach { method ->
            Text(
                method.label,
                modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(if (state.paymentMethod == method) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary).clickable { viewModel.setPaymentMethod(method) }.padding(12.dp),
                color = if (state.paymentMethod == method) Color.White else MaterialTheme.colorScheme.onSurface
            )
        }
    }
    KadamPrimaryButton("Place order") { viewModel.placeOrder(null) }
    state.placedOrderMessage?.let { Text(it, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }
}

@Composable
private fun OrdersContent(state: StoreUiState) {
    Header("Orders", "History and tracking")
    if (state.orders.isEmpty()) {
        EmptyText("No orders yet", "Your placed orders, delivery status, and summaries will appear here.")
    } else {
        state.orders.forEach { order ->
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(order.id, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text(order.items.joinToString { "${it.product.name} x${it.quantity}" })
                    Text("Status: ${order.status.label}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text("Payment: ${order.paymentMethod.label} • Total: ${rupee(order.total)}")
                    Text("${order.address.label}: ${order.address.line}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun ProfileContent(user: User, state: StoreUiState, onLogout: () -> Unit) {
    Header("Profile", "Account")
    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
        Column(modifier = Modifier.fillMaxWidth().padding(18.dp)) {
            Text(user.name, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(user.email, color = Color.White)
        }
    }
    SectionTitle("Saved addresses")
    state.addresses.forEach { address -> AddressCard(address) {} }
    SectionTitle("Notifications")
    Text("Firebase Cloud Messaging is ready to connect for order updates and offers.")
    KadamPrimaryButton("Logout", onClick = onLogout)
}

@Composable
private fun Header(title: String, subtitle: String) {
    Column {
        Text(subtitle, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
}

@Composable
private fun EmptyText(title: String, message: String) {
    Column(modifier = Modifier.fillMaxWidth().padding(32.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun AddressCard(address: Address, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(address.label, fontWeight = FontWeight.Bold)
            Text(address.line, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
