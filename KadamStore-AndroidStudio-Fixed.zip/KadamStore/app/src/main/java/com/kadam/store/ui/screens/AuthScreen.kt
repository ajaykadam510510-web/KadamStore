package com.kadam.store.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.kadam.store.data.model.AuthMode
import com.kadam.store.ui.components.KadamInput
import com.kadam.store.ui.components.KadamPrimaryButton
import com.kadam.store.viewmodel.AuthUiState

@Composable
fun AuthScreen(
    state: AuthUiState,
    onNameChange: (String) -> Unit,
    onEmailChange: (String) -> Unit,
    onPasswordChange: (String) -> Unit,
    onModeChange: (AuthMode) -> Unit,
    onLogin: () -> Unit,
    onSignup: () -> Unit,
    onForgotPassword: () -> Unit,
    onDemoLogin: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Column(
            modifier = Modifier.size(76.dp).clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.primary),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("KS", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(18.dp))
        Text("Kadam Store", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Fresh groceries, delivered before the kettle boils.", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = when (state.mode) {
                        AuthMode.Signup -> "Create your Kadam account"
                        AuthMode.Login -> "Welcome back"
                        AuthMode.Forgot -> "Reset password"
                    },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                if (state.mode == AuthMode.Signup) KadamInput(state.name, "Full name", onValueChange = onNameChange)
                KadamInput(state.email, "Email address", onValueChange = onEmailChange)
                if (state.mode != AuthMode.Forgot) {
                    androidx.compose.material3.OutlinedTextField(
                        value = state.password,
                        onValueChange = onPasswordChange,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Password") },
                        shape = RoundedCornerShape(18.dp),
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation()
                    )
                }
                state.error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold) }
                state.message?.let { Text(it, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold) }
                if (state.loading) {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
                } else {
                    KadamPrimaryButton(
                        text = when (state.mode) {
                            AuthMode.Signup -> "Sign up"
                            AuthMode.Login -> "Login"
                            AuthMode.Forgot -> "Send reset link"
                        },
                        onClick = when (state.mode) {
                            AuthMode.Signup -> onSignup
                            AuthMode.Login -> onLogin
                            AuthMode.Forgot -> onForgotPassword
                        }
                    )
                    OutlinedButton(modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(18.dp), onClick = onDemoLogin) {
                        Text("Demo Login", fontWeight = FontWeight.Bold)
                    }
                    Text("Test login: demo@kadam.store / 123456", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = { onModeChange(if (state.mode == AuthMode.Signup) AuthMode.Login else AuthMode.Signup) }) {
                        Text(if (state.mode == AuthMode.Signup) "I already have an account" else "Create account")
                    }
                    TextButton(onClick = { onModeChange(if (state.mode == AuthMode.Forgot) AuthMode.Login else AuthMode.Forgot) }) {
                        Text(if (state.mode == AuthMode.Forgot) "Back to login" else "Forgot password")
                    }
                }
            }
        }
    }
}
