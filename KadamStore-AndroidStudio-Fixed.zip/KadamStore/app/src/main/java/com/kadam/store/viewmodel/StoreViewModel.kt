package com.kadam.store.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kadam.store.data.model.Address
import com.kadam.store.data.model.CartLine
import com.kadam.store.data.model.Category
import com.kadam.store.data.model.Order
import com.kadam.store.data.model.PaymentMethod
import com.kadam.store.data.model.Product
import com.kadam.store.data.model.StoreTab
import com.kadam.store.data.repository.StoreRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update

data class StoreUiState(
    val selectedTab: StoreTab = StoreTab.Home,
    val categories: List<Category> = emptyList(),
    val products: List<Product> = emptyList(),
    val offers: List<String> = emptyList(),
    val cartLines: List<CartLine> = emptyList(),
    val addresses: List<Address> = emptyList(),
    val orders: List<Order> = emptyList(),
    val search: String = "",
    val selectedCategoryId: String? = null,
    val paymentMethod: PaymentMethod = PaymentMethod.Upi,
    val manualAddress: String = "",
    val placedOrderMessage: String? = null
) {
    val subtotal: Int get() = cartLines.sumOf { it.lineTotal }
    val deliveryFee: Int get() = if (subtotal in 1..298) 25 else 0
    val discount: Int get() = if (subtotal >= 499) 50 else 0
    val total: Int get() = subtotal + deliveryFee - discount
    val cartCount: Int get() = cartLines.sumOf { it.quantity }
    val filteredProducts: List<Product>
        get() = products.filter { product ->
            val matchesSearch = search.isBlank() || product.name.contains(search, ignoreCase = true)
            val matchesCategory = selectedCategoryId == null || product.categoryId == selectedCategoryId
            matchesSearch && matchesCategory
        }.sortedByDescending { it.rating }
}

class StoreViewModel(private val repository: StoreRepository) : ViewModel() {
    private val localState = MutableStateFlow(
        StoreUiState(
            categories = repository.categories,
            products = repository.products,
            offers = repository.offers
        )
    )

    val uiState: StateFlow<StoreUiState> = combine(
        localState,
        repository.cart,
        repository.addresses,
        repository.orders
    ) { state, _, addresses, orders ->
        state.copy(
            cartLines = repository.cartLines(),
            addresses = addresses,
            orders = orders
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), localState.value)

    fun selectTab(tab: StoreTab) = localState.update { it.copy(selectedTab = tab, placedOrderMessage = null) }
    fun setSearch(value: String) = localState.update { it.copy(search = value) }
    fun selectCategory(categoryId: String?) = localState.update { it.copy(selectedCategoryId = categoryId, selectedTab = StoreTab.Search) }
    fun addToCart(productId: String) = repository.addToCart(productId)
    fun decrement(productId: String) = repository.decrement(productId)
    fun removeFromCart(productId: String) = repository.removeFromCart(productId)
    fun clearCart() = repository.clearCart()
    fun setPaymentMethod(paymentMethod: PaymentMethod) = localState.update { it.copy(paymentMethod = paymentMethod) }
    fun setManualAddress(value: String) = localState.update { it.copy(manualAddress = value) }

    fun useCurrentLocationAddress() {
        val address = Address(
            id = "location-${System.currentTimeMillis()}",
            label = "Current location",
            line = "Pinned current location. Connect Google Maps for exact address selection."
        )
        repository.saveAddress(address)
    }

    fun placeOrder(address: Address?) {
        val state = uiState.value
        val selectedAddress = address ?: Address(
            id = "manual-${System.currentTimeMillis()}",
            label = "Manual address",
            line = state.manualAddress.trim()
        )
        if (selectedAddress.line.isBlank()) {
            localState.update { it.copy(placedOrderMessage = "Please select or enter an address") }
            return
        }
        val order = repository.placeOrder(selectedAddress, state.paymentMethod)
        localState.update {
            it.copy(
                selectedTab = if (order != null) StoreTab.Orders else StoreTab.Cart,
                manualAddress = "",
                placedOrderMessage = order?.let { placed -> "Order ${placed.id} placed successfully" } ?: "Cart is empty"
            )
        }
    }
}
