package com.kadam.store.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.kadam.store.data.model.CartLine
import com.kadam.store.data.model.Category
import com.kadam.store.data.model.Product

fun rupee(value: Int) = "₹$value"

@Composable
fun KadamPrimaryButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        modifier = modifier.fillMaxWidth().height(54.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
        onClick = onClick
    ) {
        Text(text = text, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun KadamInput(value: String, label: String, modifier: Modifier = Modifier, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        label = { Text(label) },
        shape = RoundedCornerShape(18.dp),
        singleLine = true
    )
}

@Composable
fun CategoryChip(category: Category, selected: Boolean, onClick: () -> Unit) {
    val background = if (selected) MaterialTheme.colorScheme.primary else Color(category.color)
    val foreground = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onBackground
    Column(
        modifier = Modifier
            .width(104.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(background)
            .clickable(onClick = onClick)
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(text = category.icon, color = foreground, fontWeight = FontWeight.Bold)
        Text(text = category.name, color = foreground, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ProductCard(product: Product, quantity: Int, onAdd: () -> Unit, onRemove: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.secondary),
                contentAlignment = Alignment.Center
            ) {
                Text(product.name.take(2).uppercase(), fontWeight = FontWeight.Bold)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(product.name, fontWeight = FontWeight.Bold)
                Text("${product.unit} • ${product.deliveryMinutes} min • ${product.rating}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(rupee(product.price), fontWeight = FontWeight.Bold)
                    Text(rupee(product.mrp), textDecoration = TextDecoration.LineThrough, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${((product.mrp - product.price) * 100) / product.mrp}% off", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
            }
            if (quantity == 0) {
                OutlinedButton(onClick = onAdd, shape = RoundedCornerShape(14.dp)) {
                    Text("ADD", fontWeight = FontWeight.Bold)
                }
            } else {
                Row(
                    modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primary),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("−", modifier = Modifier.clickable(onClick = onRemove).padding(horizontal = 12.dp, vertical = 8.dp), color = Color.White, fontWeight = FontWeight.Bold)
                    Text(quantity.toString(), color = Color.White, fontWeight = FontWeight.Bold)
                    Text("+", modifier = Modifier.clickable(onClick = onAdd).padding(horizontal = 12.dp, vertical = 8.dp), color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SummaryCard(subtotal: Int, deliveryFee: Int, discount: Int, total: Int, actionText: String, onAction: () -> Unit) {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SummaryLine("Subtotal", rupee(subtotal))
            SummaryLine("Delivery", if (deliveryFee == 0) "Free" else rupee(deliveryFee))
            SummaryLine("Savings", if (discount == 0) rupee(0) else "-${rupee(discount)}")
            Spacer(Modifier.height(1.dp).fillMaxWidth().background(MaterialTheme.colorScheme.outline))
            SummaryLine("Total", rupee(total), true)
            KadamPrimaryButton(actionText, onClick = onAction)
        }
    }
}

@Composable
private fun SummaryLine(label: String, value: String, strong: Boolean = false) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontWeight = if (strong) FontWeight.Bold else FontWeight.Medium)
        Text(value, fontWeight = if (strong) FontWeight.Bold else FontWeight.Medium)
    }
}

@Composable
fun CartLineRow(line: CartLine, onAdd: () -> Unit, onRemove: () -> Unit, onDelete: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(line.product.name, fontWeight = FontWeight.Bold)
            Text("${line.product.unit} • ${rupee(line.lineTotal)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Remove", modifier = Modifier.clickable(onClick = onDelete), color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
        }
        Row(modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primary), verticalAlignment = Alignment.CenterVertically) {
            Text("−", modifier = Modifier.clickable(onClick = onRemove).padding(horizontal = 12.dp, vertical = 8.dp), color = Color.White, fontWeight = FontWeight.Bold)
            Text(line.quantity.toString(), color = Color.White, fontWeight = FontWeight.Bold)
            Text("+", modifier = Modifier.clickable(onClick = onAdd).padding(horizontal = 12.dp, vertical = 8.dp), color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}
