package com.kadam.store.data.repository

import com.kadam.store.data.model.StoredUser
import com.kadam.store.data.model.User
import kotlinx.coroutines.delay

class AuthRepository {
    private val demoUser = StoredUser(
        id = "demo-user",
        name = "Kadam Customer",
        email = "demo@kadam.store",
        password = "123456"
    )

    private val users = mutableListOf(demoUser)
    private var currentUser: User? = null

    suspend fun signup(name: String, email: String, password: String): Result<User> {
        delay(250)
        val cleanEmail = email.trim().lowercase()
        if (name.trim().isEmpty()) return Result.failure(IllegalArgumentException("Please enter your name"))
        if (!cleanEmail.contains("@")) return Result.failure(IllegalArgumentException("Please enter a valid email"))
        if (password.length < 6) return Result.failure(IllegalArgumentException("Password must be at least 6 characters"))
        if (users.any { it.email == cleanEmail }) return Result.failure(IllegalArgumentException("This email is already registered"))
        val storedUser = StoredUser(
            id = System.currentTimeMillis().toString(),
            name = name.trim(),
            email = cleanEmail,
            password = password
        )
        users.add(storedUser)
        return setCurrentUser(storedUser)
    }

    suspend fun login(email: String, password: String): Result<User> {
        delay(250)
        val cleanEmail = email.trim().lowercase()
        val storedUser = users.firstOrNull { it.email == cleanEmail && it.password == password }
            ?: return Result.failure(IllegalArgumentException("Account not found. Please sign up first or use Demo Login."))
        return setCurrentUser(storedUser)
    }

    suspend fun demoLogin(): User {
        delay(150)
        return setCurrentUser(demoUser).getOrThrow()
    }

    suspend fun forgotPassword(email: String): Result<Unit> {
        delay(250)
        val cleanEmail = email.trim().lowercase()
        if (!cleanEmail.contains("@")) return Result.failure(IllegalArgumentException("Please enter a valid email"))
        if (users.none { it.email == cleanEmail }) return Result.failure(IllegalArgumentException("No account found for this email"))
        return Result.success(Unit)
    }

    fun logout() {
        currentUser = null
    }

    private fun setCurrentUser(storedUser: StoredUser): Result<User> {
        val user = User(storedUser.id, storedUser.name, storedUser.email)
        currentUser = user
        return Result.success(user)
    }
}
