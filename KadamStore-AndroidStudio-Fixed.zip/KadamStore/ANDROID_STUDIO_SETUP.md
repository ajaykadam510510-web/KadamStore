# Kadam Store Android Studio Setup

## Project path

Open this folder in Android Studio:

`KadamStore`

If you are opening it from Replit files, use:

`artifacts/mobile/android-native`

## Important before Run

If Android Studio top bar shows **No Devices**, the app will not open. Do one of these:

1. Click **Device Manager**.
2. Create an emulator, for example **Pixel 7 / Android 14 API 34**.
3. Start the emulator.
4. Select that device from the top device dropdown.
5. Click Run.

Or connect your Android phone with USB debugging enabled.

## Included Kotlin + Jetpack Compose code

- `MainActivity.kt` — app entry point
- `data/model/Models.kt` — User, Product, Category, Cart, Address, Order models
- `data/repository/AuthRepository.kt` — email/password signup, login, forgot password, demo login
- `data/repository/StoreRepository.kt` — categories, products, cart, addresses, orders
- `viewmodel/AuthViewModel.kt` — authentication MVVM state
- `viewmodel/StoreViewModel.kt` — store/cart/order MVVM state
- `ui/screens/AuthScreen.kt` — signup, login, forgot password UI
- `ui/screens/MainStoreScreen.kt` — Home, Search, Cart, Checkout, Orders, Profile
- `ui/components/StoreComponents.kt` — reusable Compose components
- `ui/theme/Theme.kt` — Kadam Store colors and Material theme

## Current MVP behavior

The Kotlin app runs with in-memory repositories so you can test the full grocery flow immediately:

- Signup
- Login
- Demo Login
- Forgot password flow placeholder
- Home screen
- Categories
- Product listing
- Search and category filtering
- Add/remove/update cart quantity
- Checkout with address and payment method
- Place order
- Order status/history
- Profile and logout

Demo login:

Email: `demo@kadam.store`
Password: `123456`

## Firebase setup

Firebase dependencies are already listed. To activate real Firebase:

1. Create a Firebase project.
2. Add Android app package `com.kadam.store`.
3. Download `google-services.json`.
4. Put it inside `app/`.
5. In `app/build.gradle.kts`, add this plugin line inside `plugins`:

```kotlin
id("com.google.gms.google-services")
```

6. Enable Email/Password in Firebase Authentication.
7. Create Firestore collections:
   - `users`
   - `products`
   - `carts`
   - `addresses`
   - `orders`
8. Use Firebase Auth inside `AuthRepository.kt`.
9. Use Firestore/Storage/FCM inside `StoreRepository.kt`.

## If Gradle sync fails

Install these in Android Studio SDK Manager:

- Android SDK Platform 34
- Android SDK Build-Tools
- Android Emulator
- Android SDK Platform-Tools

Then click **Sync Project with Gradle Files**.
