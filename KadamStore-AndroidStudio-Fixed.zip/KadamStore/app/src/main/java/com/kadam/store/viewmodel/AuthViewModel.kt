package com.kadam.store.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kadam.store.data.model.AuthMode
import com.kadam.store.data.model.User
import com.kadam.store.data.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AuthUiState(
    val mode: AuthMode = AuthMode.Signup,
    val name: String = "",
    val email: String = "",
    val password: String = "",
    val loading: Boolean = false,
    val error: String? = null,
    val message: String? = null,
    val user: User? = null
)

class AuthViewModel(private val repository: AuthRepository) : ViewModel() {
    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun onNameChange(value: String) = _uiState.update { it.copy(name = value, error = null) }
    fun onEmailChange(value: String) = _uiState.update { it.copy(email = value, error = null) }
    fun onPasswordChange(value: String) = _uiState.update { it.copy(password = value, error = null) }
    fun onModeChange(mode: AuthMode) = _uiState.update { it.copy(mode = mode, error = null, message = null) }

    fun signup() = viewModelScope.launch {
        setLoading(true)
        val state = _uiState.value
        val result = repository.signup(state.name, state.email, state.password)
        setLoading(false)
        result.fold(
            onSuccess = { user -> _uiState.update { it.copy(user = user, error = null) } },
            onFailure = { error -> _uiState.update { it.copy(error = error.message) } }
        )
    }

    fun login() = viewModelScope.launch {
        setLoading(true)
        val state = _uiState.value
        val result = repository.login(state.email, state.password)
        setLoading(false)
        result.fold(
            onSuccess = { user -> _uiState.update { it.copy(user = user, error = null) } },
            onFailure = { error -> _uiState.update { it.copy(error = error.message) } }
        )
    }

    fun demoLogin() = viewModelScope.launch {
        setLoading(true)
        val user = repository.demoLogin()
        setLoading(false)
        _uiState.update { it.copy(user = user, error = null) }
    }

    fun forgotPassword() = viewModelScope.launch {
        setLoading(true)
        val result = repository.forgotPassword(_uiState.value.email)
        setLoading(false)
        result.fold(
            onSuccess = { _uiState.update { it.copy(message = "Reset link flow is ready for Firebase Auth.", error = null) } },
            onFailure = { error -> _uiState.update { it.copy(error = error.message) } }
        )
    }

    fun logout() {
        repository.logout()
        _uiState.value = AuthUiState(mode = AuthMode.Login)
    }

    private fun setLoading(value: Boolean) = _uiState.update { it.copy(loading = value) }
}
