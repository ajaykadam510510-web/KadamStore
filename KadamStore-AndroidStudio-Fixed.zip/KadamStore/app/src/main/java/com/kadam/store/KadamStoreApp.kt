package com.kadam.store

import android.app.Application

class KadamStoreApp : Application()
